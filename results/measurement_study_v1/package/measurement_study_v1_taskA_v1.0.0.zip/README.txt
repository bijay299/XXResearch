Image review — Task A
=====================

WHAT TO DO
1. Unzip this folder somewhere convenient (keep all files together).
2. Open index.html by double-clicking it, or drag it into a web browser.
   Chrome, Firefox, Edge and Safari all work. No account, no install, no internet.
3. Enter the short alias your coordinator gave you, pick the order variant they
   assigned (A, B or C), and answer the prior-exposure question honestly.
4. Work through the items. Your progress saves automatically in this browser.
5. When finished, press "Export final" and send the downloaded .json file back to
   your coordinator however they asked.

NOTES
- "Uncertain" and "Unable to judge" are real answers. Please use them rather than
  guessing. There is no score and no right answer.
- You are not told which model or method produced any image, on purpose.
- Please work on your own and do not discuss individual images with other reviewers.
- Nothing is uploaded. Everything stays on your computer until you send the file.
- If you need to continue on another machine, press "Export draft", move that file,
  and import it there.

PRIVACY
The exported file contains only your alias, your answers, and package/protocol ids.
Please do not type your name, email or any other identifying detail anywhere.

PACKAGE
  package id : msv1-taskA-v1.0.0
  protocol   : msv1-protocol-v1
  schema     : msv1-response-schema v1.0.0
